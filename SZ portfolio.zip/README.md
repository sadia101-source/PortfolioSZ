
  # Receive User Code

  This is a code bundle for Receive User Code. The original project is available at https://www.figma.com/design/2GYIQ0qb6UsYQV3YgfrWRv/Receive-User-Code.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  