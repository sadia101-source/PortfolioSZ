import { MusicPlayer } from './MusicPlayer';
import { AnimatedCat } from './AnimatedCat';

interface TaskbarProps {
  time?: string;
}

export function Taskbar({ time = new Date().toLocaleTimeString() }: TaskbarProps) {
  return (
    <div 
      className="fixed bottom-0 left-0 right-0 h-12 bg-[#c0c0c0] flex items-center px-2 gap-2 z-50"
      style={{
        boxShadow: 'inset 0 1px #fff, inset 1px 0 #fff',
      }}
    >
      {/* Start Button */}
      <button
        className="px-3 py-1 bg-[#c0c0c0] flex items-center gap-2 hover:bg-[#dfdfdf] transition-colors"
        style={{
          boxShadow: 'inset 2px 2px #fff, inset -2px -2px #000, inset 4px 4px #dfdfdf',
        }}
      >
        <div className="w-5 h-5 bg-gradient-to-br from-red-500 via-yellow-500 to-blue-500 rounded-sm"></div>
        <span className="font-bold text-sm">Start</span>
      </button>

      {/* Separator */}
      <div className="h-8 w-px bg-[#808080]"></div>

      {/* Animated Cat Area */}
      <div className="w-32 h-full relative">
        <AnimatedCat />
      </div>

      {/* Music Player */}
      <MusicPlayer />

      {/* Spacer */}
      <div className="flex-1"></div>

      {/* Instagram */}
      <a
        href="https://instagram.com/sadia.zafreen"
        target="_blank"
        rel="noopener noreferrer"
        className="px-2 py-1 bg-[#c0c0c0] flex items-center gap-1.5 hover:bg-[#dfdfdf] transition-all hover:scale-105"
        style={{
          boxShadow: 'inset -2px -2px #fff, inset 2px 2px #000',
        }}
        title="Follow on Instagram"
      >
        {/* Instagram Logo SVG */}
        <svg 
          width="16" 
          height="16" 
          viewBox="0 0 24 24" 
          fill="none" 
          xmlns="http://www.w3.org/2000/svg"
          className="flex-shrink-0"
        >
          <defs>
            <linearGradient id="instagramGradient" x1="0%" y1="100%" x2="100%" y2="0%">
              <stop offset="0%" style={{ stopColor: '#FD5949', stopOpacity: 1 }} />
              <stop offset="50%" style={{ stopColor: '#D6249F', stopOpacity: 1 }} />
              <stop offset="100%" style={{ stopColor: '#285AEB', stopOpacity: 1 }} />
            </linearGradient>
          </defs>
          <rect x="2" y="2" width="20" height="20" rx="5" stroke="url(#instagramGradient)" strokeWidth="2" fill="none"/>
          <circle cx="12" cy="12" r="4" stroke="url(#instagramGradient)" strokeWidth="2" fill="none"/>
          <circle cx="18" cy="6" r="1.5" fill="url(#instagramGradient)"/>
        </svg>
        <span className="text-xs font-semibold">@sadia.zafreen</span>
      </a>

      {/* Clock */}
      <div 
        className="px-3 py-1 bg-[#c0c0c0] min-w-[80px] text-center"
        style={{
          boxShadow: 'inset -2px -2px #fff, inset 2px 2px #000',
        }}
      >
        <span className="text-sm">{time}</span>
      </div>
    </div>
  );
}
