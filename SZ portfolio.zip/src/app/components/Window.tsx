import { useState, useRef, useEffect } from 'react';

interface WindowProps {
  title: string;
  children: React.ReactNode;
  initialX?: number;
  initialY?: number;
  width?: number;
  height?: number;
  onClose?: () => void;
  rounded?: boolean;
}

export function Window({ 
  title, 
  children, 
  initialX = 100, 
  initialY = 100,
  width = 600,
  height = 400,
  onClose,
  rounded = false
}: WindowProps) {
  const [position, setPosition] = useState({ x: initialX, y: initialY });
  const [isDragging, setIsDragging] = useState(false);
  const dragRef = useRef({ startX: 0, startY: 0 });

  const handleMouseDown = (e: React.MouseEvent) => {
    setIsDragging(true);
    dragRef.current = {
      startX: e.clientX - position.x,
      startY: e.clientY - position.y,
    };
  };

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (isDragging) {
        setPosition({
          x: e.clientX - dragRef.current.startX,
          y: e.clientY - dragRef.current.startY,
        });
      }
    };

    const handleMouseUp = () => {
      setIsDragging(false);
    };

    if (isDragging) {
      window.addEventListener('mousemove', handleMouseMove);
      window.addEventListener('mouseup', handleMouseUp);
    }

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
    };
  }, [isDragging]);

  return (
    <div
      className="absolute bg-[#c0c0c0] flex flex-col"
      style={{
        left: `${position.x}px`,
        top: `${position.y}px`,
        width: `${width}px`,
        height: `${height}px`,
        borderRadius: rounded ? '8px' : '0',
        boxShadow: 'inset -2px -2px #000, inset 0 0 0 3px #808080, inset -6px -6px rgba(192, 192, 192, 0.25), inset 0 0 0 5px #fff, inset 0 0 0 7px #808080',
      }}
    >
      {/* Title Bar */}
      <div
        className="bg-[#000080] flex items-center justify-between px-2 py-1 cursor-move select-none"
        style={{
          borderTopLeftRadius: rounded ? '8px' : '0',
          borderTopRightRadius: rounded ? '8px' : '0',
        }}
        onMouseDown={handleMouseDown}
      >
        <span className="text-white text-sm font-bold">{title}</span>
        {onClose && (
          <button
            className="w-4 h-4 bg-[#c0c0c0] flex items-center justify-center text-xs"
            style={{
              boxShadow: 'inset 1px 1px #fff, inset -1px -1px #000',
            }}
            onClick={onClose}
          >
            ✕
          </button>
        )}
      </div>

      {/* Rainbow Divider */}
      <div className="flex h-1">
        <div className="flex-1 bg-[#fc3000]"></div>
        <div className="flex-1 bg-[#fccc00]"></div>
        <div className="flex-1 bg-[#68cc38]"></div>
        <div className="flex-1 bg-[#009cfc]"></div>
        <div className="flex-1 bg-[#8fd0fb]"></div>
      </div>

      {/* Content */}
      <div 
        className="flex-1 overflow-auto bg-white m-2"
        style={{
          borderRadius: rounded ? '4px' : '0',
        }}
      >
        {children}
      </div>
    </div>
  );
}