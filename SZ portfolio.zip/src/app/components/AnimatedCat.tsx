import { useState, useEffect } from 'react';

export function AnimatedCat() {
  const [isWalking, setIsWalking] = useState(false);
  const [position, setPosition] = useState(0);
  const [direction, setDirection] = useState<'right' | 'left'>('right');

  useEffect(() => {
    const walkInterval = setInterval(() => {
      const shouldWalk = Math.random() > 0.7;
      setIsWalking(shouldWalk);

      if (shouldWalk) {
        setPosition((prev) => {
          const newPos = direction === 'right' ? prev + 5 : prev - 5;
          
          // Change direction if reached bounds
          if (newPos > 100) {
            setDirection('left');
            return 100;
          } else if (newPos < 0) {
            setDirection('right');
            return 0;
          }
          
          return newPos;
        });
      }
    }, 500);

    return () => clearInterval(walkInterval);
  }, [direction]);

  return (
    <div className="relative h-full flex items-center">
      <div
        className="absolute text-2xl transition-all duration-500 cursor-pointer hover:scale-110"
        style={{
          left: `${position}px`,
          transform: direction === 'left' ? 'scaleX(-1)' : 'scaleX(1)',
        }}
        title="This is a pixel cat! Click me!"
      >
        <span className={isWalking ? 'animate-bounce' : ''}>🐱</span>
      </div>
    </div>
  );
}
