import { useState, useEffect } from 'react';
import { Window } from './components/Window';
import { DesktopIcon } from './components/DesktopIcon';
import { Taskbar } from './components/Taskbar';
import hollowBoundImg from 'figma:asset/481cde8efe3d49d4500e5dc34aa224555841ff0b.png';
import studySphereImg from 'figma:asset/be7314db72a5e341bb2cb0e41d2d8137d8365c96.png';
import factFlowImg from 'figma:asset/3c0d104a57fd1ea7f2803afc2b02f72424aed45c.png';
import hollowBoundDetail from 'figma:asset/4424233f6b54c0be58e452071173fd9be62a79aa.png';
import studySphereDetail from 'figma:asset/7aa6bb78ffac761b6521a5e0b0c5d8477392a9f1.png';
import factFlowDetail from 'figma:asset/57b5558e21a4209ece0d3bc8dd5ab3115aeca385.png';
import wallpaperImg from 'figma:asset/b2e6a6ddbbc75ffa9bb90de28ecaa0089808a0c5.png';
import profileImg from 'figma:asset/f6aa907560050aa6840c68dcdc2f9934dd480c70.png';

export default function App() {
  const [currentTime, setCurrentTime] = useState(new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }));
  const [openWindows, setOpenWindows] = useState<{ [key: string]: boolean }>({
    welcome: true,
    about: false,
    projects: false,
    contact: false,
    hollowbound: false,
    studysphere: false,
    factflow: false,
  });

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }));
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const openWindow = (window: string) => {
    setOpenWindows(prev => ({ ...prev, [window]: true }));
  };

  const closeWindow = (window: string) => {
    setOpenWindows(prev => ({ ...prev, [window]: false }));
  };

  const projects = [
    {
      id: 'hollowbound',
      title: 'HollowBound',
      description: 'Team 404 Code Won first position in the IEEE GameJam 2025',
      tech: ['Unity', 'C#', 'GitHub'],
      image: hollowBoundImg,
      detailImage: hollowBoundDetail,
      fullDescription: `Hollowbound is a first-person psychological horror escape game following the theme: a disconnect from real world. 

Sound is your only weapon — and your biggest enemy.

In Hollowbound, silence is deadly.
If the environment goes quiet for too long, you will be followed. 

The deeper you go, the more distorted reality becomes. Even your own footsteps may start to lie.`,
    },
    {
      id: 'studysphere',
      title: 'AMU StudySphere',
      description: 'Team 404 Won third position in the IEEE WIE Ideathon 2025',
      tech: ['Figma', 'Canva', 'Wireframer'],
      image: studySphereImg,
      detailImage: studySphereDetail,
      fullDescription: `AMU StudySphere is a comprehensive AI-powered platform designed to streamline academic life for AMU students and faculty.

It combines study planning, AI-powered tools, multilingual support, club management, mentorship, and collaboration features to create a one-stop solution for managing learning and teaching activities.`,
    },
    {
      id: 'factflow',
      title: 'Fact Flow',
      description: '404 Code Won first round of the Ignite Hackathon by Codechef x StarLabs',
      tech: ['Google API', 'React.js', 'Node.js'],
      image: factFlowImg,
      detailImage: factFlowDetail,
      fullDescription: `FactFlow is an AI-powered fact verification platform that helps users instantly check the credibility of online information. 

It analyzes text using real-time data sources and provides reliable truth scores to combat misinformation.`,
    },
  ];

  return (
    <div className="h-screen w-screen overflow-hidden relative">
      {/* Background Wallpaper - Natural Colors, No Tint */}
      <div 
        className="absolute inset-0 z-0"
        style={{
          backgroundImage: `url(${wallpaperImg})`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
        }}
      ></div>

      {/* Desktop Icons */}
      <div className="absolute top-4 left-4 flex flex-col gap-2 z-10">
        <DesktopIcon
          icon="💼"
          label="My Portfolio"
          onClick={() => openWindow('about')}
        />
        <DesktopIcon
          icon="📁"
          label="Projects"
          onClick={() => openWindow('projects')}
        />
        <DesktopIcon
          icon="📧"
          label="Contact"
          onClick={() => openWindow('contact')}
        />
        <DesktopIcon
          icon="🗑️"
          label="Recycle Bin"
        />
      </div>

      {/* Welcome Window */}
      {openWindows.welcome && (
        <Window
          title="Welcome to PixelOS"
          initialX={200}
          initialY={150}
          width={500}
          height={300}
          onClose={() => closeWindow('welcome')}
        >
          <div className="p-8 flex flex-col items-center justify-center h-full gap-6">
            <h1 className="text-xl font-bold text-center">Welcome to My Portfolio</h1>
            <div className="flex flex-col gap-4 w-full max-w-xs">
              <button
                onClick={() => openWindow('about')}
                className="px-6 py-3 bg-[#c0c0c0] text-left hover:bg-[#dfdfdf]"
                style={{
                  boxShadow: 'inset 2px 2px #fff, inset -2px -2px #808080',
                }}
              >
                💼 My Portfolio
              </button>
              <button
                onClick={() => openWindow('projects')}
                className="px-6 py-3 bg-[#c0c0c0] text-left hover:bg-[#dfdfdf]"
                style={{
                  boxShadow: 'inset 2px 2px #fff, inset -2px -2px #808080',
                }}
              >
                📁 Projects
              </button>
              <button
                onClick={() => openWindow('contact')}
                className="px-6 py-3 bg-[#c0c0c0] text-left hover:bg-[#dfdfdf]"
                style={{
                  boxShadow: 'inset 2px 2px #fff, inset -2px -2px #808080',
                }}
              >
                📧 Contact
              </button>
            </div>
          </div>
        </Window>
      )}

      {/* About Window */}
      {openWindows.about && (
        <Window
          title="About Me"
          initialX={250}
          initialY={100}
          width={580}
          height={600}
          onClose={() => closeWindow('about')}
        >
          <div className="p-6">
            <h1 className="text-2xl font-bold mb-4">About Me</h1>
            <div className="flex items-start gap-4 mb-4">
              <img 
                src={profileImg}
                alt="Sadia Zafreen"
                className="w-24 h-24 object-cover rounded-lg"
                style={{
                  boxShadow: 'inset -1px -1px #fff, inset 1px 1px #000',
                }}
              />
              <div className="flex-1">
                <h2 className="text-xl font-bold">Sadia Zafreen</h2>
                <p className="text-sm text-gray-600">Web Developer</p>
              </div>
            </div>
            <div className="space-y-3">
              <div>
                <h3 className="font-bold mb-2">About</h3>
                <p className="text-sm mb-2">
                  I'm a developer, I enjoy building cool projects and diving into latest technologies.
                </p>
                <p className="text-sm leading-relaxed">
                  I'm a passionate developer who enjoys building cool, meaningful, and interactive projects. I love turning ideas into real-world applications and experimenting with new technologies. I'm especially interested in creating user-friendly interfaces, playful interactions, and products that feel alive. I'm always curious, constantly learning, and motivated to improve my craft through hands-on projects.
                </p>
              </div>
              <div>
                <h3 className="font-bold mb-2">Skills</h3>
                <div className="flex flex-wrap gap-2">
                  {[
                    'Python',
                    'Java',
                    'C',
                    'Kotlin',
                    'MongoDB',
                    'React',
                    'Node.js',
                    'HTML',
                    'CSS',
                    'JavaScript',
                    'Tailwind CSS'
                  ].map(skill => (
                    <span
                      key={skill}
                      className="px-2 py-1 bg-[#c0c0c0] text-xs hover:bg-[#dfdfdf] transition-colors"
                      style={{
                        boxShadow: 'inset 1px 1px #fff, inset -1px -1px #808080',
                      }}
                    >
                      {skill}
                    </span>
                  ))}
                </div>
              </div>
              <div>
                <h3 className="font-bold mb-2">Education</h3>
                <div className="space-y-2">
                  <div>
                    <p className="text-sm font-semibold">B.Sc. (Hons.) Computer Applications</p>
                    <p className="text-xs text-gray-600">VSC</p>
                  </div>
                  <div>
                    <p className="text-sm font-semibold">Senior Secondary (12th Grade)</p>
                    <p className="text-xs text-gray-600">Girls Senior Secondary School</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </Window>
      )}

      {/* Projects Window */}
      {openWindows.projects && (
        <Window
          title="My Projects"
          initialX={300}
          initialY={80}
          width={700}
          height={550}
          onClose={() => closeWindow('projects')}
        >
          <div className="p-6">
            <h1 className="text-2xl font-bold mb-4">Featured Projects</h1>
            <div className="space-y-4">
              {projects.map((project, index) => (
                <button
                  key={index}
                  onClick={() => openWindow(project.id)}
                  className="w-full p-4 bg-[#c0c0c0] hover:bg-[#dfdfdf] transition-colors cursor-pointer"
                  style={{
                    boxShadow: 'inset -1px -1px #fff, inset 1px 1px #808080',
                  }}
                >
                  <div className="flex gap-4 items-start">
                    <img 
                      src={project.image} 
                      alt={project.title}
                      className="w-24 h-24 object-cover"
                      style={{
                        boxShadow: 'inset -1px -1px #fff, inset 1px 1px #000',
                      }}
                    />
                    <div className="flex-1 text-left">
                      <h3 className="font-bold mb-2 text-lg">{project.title}</h3>
                      <p className="text-sm mb-2">{project.description}</p>
                      <div className="flex gap-2 flex-wrap">
                        {project.tech.map(tech => (
                          <span
                            key={tech}
                            className="px-2 py-0.5 bg-white text-xs"
                            style={{
                              boxShadow: 'inset -1px -1px #c0c0c0, inset 1px 1px #808080',
                            }}
                          >
                            {tech}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </Window>
      )}

      {/* Project Detail Windows */}
      {projects.map((project) => (
        openWindows[project.id] && (
          <Window
            key={project.id}
            title={project.title}
            initialX={150 + projects.findIndex(p => p.id === project.id) * 50}
            initialY={120 + projects.findIndex(p => p.id === project.id) * 50}
            width={800}
            height={600}
            onClose={() => closeWindow(project.id)}
            rounded={true}
          >
            <div className="p-6">
              <img 
                src={project.detailImage} 
                alt={project.title}
                className="w-full h-64 object-cover mb-4 rounded-lg"
              />
              <h2 className="text-xl font-bold mb-3">{project.title}</h2>
              <div className="mb-4 p-3 bg-[#fffacd] rounded" style={{ border: '1px solid #ffd700' }}>
                <p className="text-sm font-semibold">🏆 {project.description}</p>
              </div>
              <div className="mb-4">
                <h3 className="font-bold mb-2">About the Project</h3>
                <p className="text-sm whitespace-pre-line leading-relaxed">
                  {project.fullDescription}
                </p>
              </div>
              <div>
                <h3 className="font-bold mb-2">Technologies Used</h3>
                <div className="flex gap-2 flex-wrap">
                  {project.tech.map(tech => (
                    <span
                      key={tech}
                      className="px-3 py-1.5 bg-[#c0c0c0] text-sm"
                      style={{
                        boxShadow: 'inset 1px 1px #fff, inset -1px -1px #808080',
                      }}
                    >
                      {tech}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </Window>
        )
      ))}

      {/* Contact Window */}
      {openWindows.contact && (
        <Window
          title="Contact Me"
          initialX={350}
          initialY={120}
          width={450}
          height={350}
          onClose={() => closeWindow('contact')}
        >
          <div className="p-6">
            <h1 className="text-2xl font-bold mb-4">Get In Touch</h1>
            <div className="space-y-4">
              <div>
                <label className="block font-bold mb-1">Email</label>
                <a 
                  href="mailto:sadiazafreen525@gmail.com" 
                  className="text-blue-600 hover:underline text-sm"
                >
                  sadiazafreen525@gmail.com
                </a>
              </div>
              <div>
                <label className="block font-bold mb-1">Social Media</label>
                <div className="space-y-2">
                  <a 
                    href="https://www.linkedin.com/in/sadia-zafreen-067295330" 
                    target="_blank"
                    rel="noopener noreferrer"
                    className="block text-blue-600 hover:underline text-sm"
                  >
                    🔗 LinkedIn
                  </a>
                  <a 
                    href="https://github.com/sadia101-source" 
                    target="_blank"
                    rel="noopener noreferrer"
                    className="block text-blue-600 hover:underline text-sm"
                  >
                    🐙 GitHub
                  </a>
                </div>
              </div>
              <div className="border-t-2 border-[#808080] my-4"></div>
              <button
                className="px-4 py-2 bg-[#c0c0c0] w-full hover:bg-[#dfdfdf]"
                style={{
                  boxShadow: 'inset 2px 2px #fff, inset -2px -2px #808080',
                }}
              >
                Download Resume
              </button>
            </div>
          </div>
        </Window>
      )}

      {/* Taskbar */}
      <Taskbar time={currentTime} />
    </div>
  );
}