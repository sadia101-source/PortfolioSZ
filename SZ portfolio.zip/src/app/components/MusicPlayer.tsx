import { useState, useRef, useEffect } from 'react';

export function MusicPlayer() {
  const [isPlaying, setIsPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const audioRef = useRef<HTMLAudioElement>(null);

  // Using a public domain music file URL (chill/indie vibe)
  const audioUrl = 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3';

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;

    const updateProgress = () => {
      setCurrentTime(audio.currentTime);
      setProgress((audio.currentTime / audio.duration) * 100);
    };

    const setAudioDuration = () => {
      setDuration(audio.duration);
    };

    audio.addEventListener('timeupdate', updateProgress);
    audio.addEventListener('loadedmetadata', setAudioDuration);

    return () => {
      audio.removeEventListener('timeupdate', updateProgress);
      audio.removeEventListener('loadedmetadata', setAudioDuration);
    };
  }, []);

  const togglePlay = () => {
    const audio = audioRef.current;
    if (!audio) return;

    if (isPlaying) {
      audio.pause();
    } else {
      audio.play();
    }
    setIsPlaying(!isPlaying);
  };

  const formatTime = (seconds: number) => {
    if (isNaN(seconds)) return '0:00';
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div
      className="bg-[#c0c0c0] p-2 flex items-center gap-2 min-w-[200px]"
      style={{
        boxShadow: 'inset -1px -1px #fff, inset 1px 1px #808080',
      }}
    >
      <audio ref={audioRef} src={audioUrl} />
      
      {/* Play/Pause Button */}
      <button
        onClick={togglePlay}
        className="w-8 h-8 bg-[#c0c0c0] flex items-center justify-center hover:bg-[#dfdfdf] transition-colors"
        style={{
          boxShadow: 'inset 2px 2px #fff, inset -2px -2px #808080',
        }}
      >
        {isPlaying ? '⏸' : '▶'}
      </button>

      {/* Progress Container */}
      <div className="flex-1">
        <div
          className="h-4 bg-white relative cursor-pointer"
          style={{
            boxShadow: 'inset -1px -1px #fff, inset 1px 1px #000',
          }}
          onClick={(e) => {
            const audio = audioRef.current;
            if (!audio) return;
            const rect = e.currentTarget.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const clickedValue = (x / rect.width) * audio.duration;
            audio.currentTime = clickedValue;
          }}
        >
          <div
            className="h-full bg-[#000080] transition-all"
            style={{ width: `${progress}%` }}
          ></div>
        </div>
        <div className="text-xs mt-1 text-center">
          {formatTime(currentTime)} / {formatTime(duration)}
        </div>
      </div>

      {/* Volume Icon */}
      <div className="text-sm">🔊</div>
    </div>
  );
}
