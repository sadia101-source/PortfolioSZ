interface DesktopIconProps {
  icon: string;
  label: string;
  onClick?: () => void;
}

export function DesktopIcon({ icon, label, onClick }: DesktopIconProps) {
  return (
    <button
      onClick={onClick}
      className="flex flex-col items-center gap-1 p-2 w-20 cursor-pointer hover:bg-[#000080]/30 group"
    >
      <div className="text-4xl">{icon}</div>
      <span className="text-white text-xs text-center break-words px-1 py-0.5 group-hover:bg-[#000080]">
        {label}
      </span>
    </button>
  );
}
